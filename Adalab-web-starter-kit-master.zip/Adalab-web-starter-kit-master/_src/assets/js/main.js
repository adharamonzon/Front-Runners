'use strict';

console.log('>> Ready :)');
